This directory is for files that should be installed at the top level
of the INSTALL_PREFIX/share/proton directory to support installed
testing.
